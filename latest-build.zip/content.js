// src/core/summaryQueries.ts
var readModelQueries = (metadata) => {
  const queries = metadata?.search_model_queries?.queries;
  return Array.isArray(queries) ? queries.filter((query) => typeof query === "string" && query.length > 0) : [];
};
var readSearchQueries = (metadata) => {
  const items = metadata?.search_queries;
  if (!Array.isArray(items)) return [];
  return items.filter((item) => item?.type === "search" && typeof item?.q === "string" && item.q.length > 0).map((item) => item.q);
};
var readQueries = (metadata) => {
  const model = readModelQueries(metadata);
  if (model.length) return model;
  return readSearchQueries(metadata);
};
var ancestorQueries = (node, mapping, maxDepth = 3) => {
  let current = node.parent ? mapping[node.parent] : void 0;
  for (let depth = 0; depth < maxDepth && current; depth++) {
    const queries = readQueries(current.message?.metadata);
    if (queries.length) return queries;
    current = current.parent ? mapping[current.parent] : void 0;
  }
  return [];
};
var resolveQueries = (node, mapping) => {
  const fromNode = readQueries(node.message?.metadata);
  if (fromNode.length) return fromNode;
  const fromAncestors = ancestorQueries(node, mapping);
  return fromAncestors.length ? fromAncestors : ["no search query identified"];
};

// src/core/parseSearchEvent.ts
var safeJson = (text) => {
  if (!text) return void 0;
  try {
    return JSON.parse(text);
  } catch {
    return void 0;
  }
};
var toMapping = (parsed) => {
  if (!parsed || typeof parsed !== "object") return {};
  const mapping = parsed.mapping;
  return mapping && typeof mapping === "object" ? mapping : {};
};
var sortNodes = (mapping) => Object.values(mapping).filter((node) => typeof node.message?.create_time === "number").sort((a, b) => (a.message?.create_time ?? 0) - (b.message?.create_time ?? 0));
var resolveQuery = (node, mapping) => resolveQueries(node, mapping).join(", ");
var toResults = (groups) => {
  if (!Array.isArray(groups)) return [];
  return groups.flatMap((groupRaw) => {
    const group = groupRaw;
    const entries = Array.isArray(group.entries) ? group.entries : [];
    return entries.flatMap((entryRaw) => {
      const entry = entryRaw;
      if (entry.type !== "search_result" || typeof entry.url !== "string") return [];
      const title = typeof entry.title === "string" ? entry.title : entry.url;
      const attribution = typeof group.domain === "string" ? group.domain : typeof entry.attribution === "string" ? entry.attribution : void 0;
      return [{ title, url: entry.url, snippet: typeof entry.snippet === "string" ? entry.snippet : void 0, pub_date: typeof entry.pub_date === "number" ? entry.pub_date : entry.pub_date === null ? null : void 0, attribution, ref_id: typeof entry.ref_id === "object" && entry.ref_id ? entry.ref_id : void 0, type: "organic" }];
    });
  });
};
var toEvent = (node, capture, mapping) => {
  const metadata = node.message?.metadata;
  const results = toResults(metadata?.search_result_groups);
  const time = node.message?.create_time;
  if (!results.length || typeof time !== "number") return void 0;
  const ms = time * 1e3;
  const query = resolveQuery(node, mapping);
  return { id: node.message?.id ?? `evt-${time}`, query, url: capture.url, method: capture.method, status: capture.status, resultCount: results.length, results, rawResponse: capture.responseBody, startedAt: ms, completedAt: ms };
};
var parseSearchEvents = (capture) => {
  const mapping = toMapping(safeJson(capture.responseBody));
  return sortNodes(mapping).map((node) => toEvent(node, capture, mapping)).filter((event) => Boolean(event));
};
var parseSearchEvent = (capture) => parseSearchEvents(capture)[0];

// src/infra/effectContentWatcher.ts
var safeRequestBody = async (input, init) => {
  if (typeof init?.body === "string") return init.body;
  if (input instanceof Request) {
    try {
      const clone = input.clone();
      return await clone.text();
    } catch {
      return void 0;
    }
  }
  return void 0;
};
var safeResponseBody = async (response) => {
  try {
    return await response.clone().text();
  } catch {
    return void 0;
  }
};
var buildCapture = async (args, response, startedAt) => {
  const [input, init] = args;
  const url = typeof input === "string" || input instanceof URL ? input.toString() : input.url;
  const method = init?.method ?? (input instanceof Request ? input.method : "GET");
  const requestBody = await safeRequestBody(input, init);
  const responseBody = await safeResponseBody(response);
  return { url, method, requestBody, responseBody, status: response.status, startedAt, completedAt: Date.now() };
};
var processFetch = async (args, response, startedAt) => {
  const capture = await buildCapture(args, response, startedAt);
  const event = parseSearchEvent(capture);
  if (event) void chrome.runtime.sendMessage({ type: "search-event", event });
};
var wrapFetchOnce = () => {
  const original = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const startedAt = Date.now();
    const response = await original(...args);
    void processFetch(args, response, startedAt);
    return response;
  };
};
wrapFetchOnce();
