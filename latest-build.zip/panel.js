// src/core/summaryResults.ts
var isSearchEntry = (entry) => Boolean(entry?.type === "search_result" && typeof entry.url === "string");
var pickAttribution = (group, entry) => {
  if (typeof group.domain === "string" && group.domain.length > 0) return group.domain;
  return typeof entry.attribution === "string" && entry.attribution.length > 0 ? entry.attribution : void 0;
};
var normalizeDate = (value) => {
  if (typeof value === "number") return value;
  return value === null ? null : void 0;
};
var buildResult = (entry, group) => ({
  title: typeof entry.title === "string" && entry.title.length ? entry.title : entry.url ?? "",
  url: entry.url ?? "",
  snippet: typeof entry.snippet === "string" ? entry.snippet : "",
  attribution: pickAttribution(group, entry),
  pub_date: normalizeDate(entry.pub_date),
  ref_id: typeof entry.ref_id === "object" && entry.ref_id ? entry.ref_id : void 0,
  type: "organic",
  rawJson: JSON.stringify(entry, null, 2)
});
var extractResults = (groups) => {
  if (!Array.isArray(groups)) return [];
  return groups.flatMap((group) => (group.entries ?? []).filter(isSearchEntry).map((entry) => buildResult(entry, group)));
};

// src/core/summaryQueries.ts
var readQueries = (metadata) => {
  const queries = metadata?.search_model_queries?.queries;
  return Array.isArray(queries) ? queries.filter((query) => typeof query === "string" && query.length > 0) : [];
};
var parentQueries = (node, mapping) => {
  if (!node.parent) return [];
  const parent = mapping[node.parent];
  return parent ? readQueries(parent.message?.metadata) : [];
};
var resolveQueries = (node, mapping) => {
  const fromNode = readQueries(node.message?.metadata);
  if (fromNode.length) return fromNode;
  const fromParent = parentQueries(node, mapping);
  return fromParent.length ? fromParent : ["no search query identified"];
};

// src/core/summaryEvents.ts
var buildQueries = (node, mapping, results) => resolveQueries(node, mapping).map((query) => ({ query, results }));
var toEvent = (node, mapping) => {
  const time = node.message?.create_time;
  const results = extractResults(node.message?.metadata?.search_result_groups);
  if (!results.length || typeof time !== "number") return void 0;
  return { id: node.message?.id ?? `evt-${time}`, timestamp: time * 1e3, queries: buildQueries(node, mapping, results) };
};
var mapToEvents = (nodes, mapping) => nodes.map((node) => toEvent(node, mapping)).filter((event) => Boolean(event));

// src/core/summaryMapping.ts
var parseJson = (raw) => {
  if (!raw) return void 0;
  try {
    return JSON.parse(raw);
  } catch {
    return void 0;
  }
};
var toMapping = (parsed) => {
  if (!parsed || typeof parsed !== "object") return {};
  const mapping = parsed.mapping;
  return mapping && typeof mapping === "object" ? mapping : {};
};
var sortNodes = (mapping) => Object.values(mapping).filter((node) => typeof node.message?.create_time === "number").sort((a, b) => (a.message?.create_time ?? 0) - (b.message?.create_time ?? 0));
var parseNodes = (rawJson) => {
  const mapping = toMapping(parseJson(rawJson));
  return { mapping, nodes: sortNodes(mapping) };
};

// src/core/parseSummary.ts
var parseSummaryFromJson = (rawJson) => {
  const { mapping, nodes } = parseNodes(rawJson);
  return mapToEvents(nodes, mapping);
};

// src/core/stats.ts
var rootDomain = (url) => {
  try {
    const host = new URL(url).hostname.toLowerCase();
    const parts = host.split(".").filter(Boolean);
    if (parts.length >= 2) return `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
    return host;
  } catch {
    return void 0;
  }
};
var addEvent = (event, queries, domains, urls) => {
  if (event.query) queries.add(event.query);
  event.results.forEach((result) => {
    if (!result.url) return;
    urls.set(result.url, (urls.get(result.url) ?? 0) + 1);
    const domain = rootDomain(result.url);
    if (domain) domains.set(domain, (domains.get(domain) ?? 0) + 1);
  });
};
var countSummaryEvents = (events) => events.reduce((sum, event) => sum + parseSummaryFromJson(event.rawResponse).length, 0);
var buildStats = (events) => {
  const queries = /* @__PURE__ */ new Set();
  const domains = /* @__PURE__ */ new Map();
  const urls = /* @__PURE__ */ new Map();
  events.forEach((event) => addEvent(event, queries, domains, urls));
  return {
    events: countSummaryEvents(events),
    queries: Array.from(queries).sort(),
    domains: Array.from(domains.entries()).sort((a, b) => b[1] - a[1]).map(([d, c]) => `${d} (${c}x)`),
    urls: Array.from(urls.entries()).sort((a, b) => b[1] - a[1]).map(([url, count]) => ({ url, count }))
  };
};

// src/ui/dom.ts
var byId = (id) => document.getElementById(id);
var setHtml = (element, html) => {
  if (element) element.innerHTML = html;
};
var escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
var formatJson = (text) => {
  try {
    return JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    return text;
  }
};
var formatDate = (timestamp) => !timestamp ? "" : new Date(timestamp * 1e3).toLocaleDateString();
var flashText = (element, next, fallback) => {
  if (!element) return;
  element.textContent = next;
  setTimeout(() => {
    element.textContent = fallback;
  }, 1500);
};
var styleToast = (toast) => {
  Object.assign(toast.style, {
    position: "fixed",
    bottom: "12px",
    right: "12px",
    background: "#0b57d0",
    color: "#fff",
    padding: "6px 10px",
    borderRadius: "8px",
    fontSize: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.2)"
  });
};
var ensureToast = () => {
  const existing = document.getElementById("toast-banner");
  if (existing) return existing;
  const toast = document.createElement("div");
  toast.id = "toast-banner";
  styleToast(toast);
  document.body.appendChild(toast);
  return toast;
};
var showToast = (message) => {
  const toast = ensureToast();
  toast.textContent = message;
  toast.style.opacity = "1";
  setTimeout(() => {
    toast.style.opacity = "0";
  }, 1200);
};

// src/ui/copyAll.ts
var formatResult = (result, idx) => {
  const lines = [`${idx + 1}. ${result.title}`, `   URL: ${result.url}`];
  if (result.snippet) lines.push(`   Snippet: ${result.snippet}`);
  if (result.attribution) lines.push(`   Source: ${result.attribution}`);
  if (result.pub_date) lines.push(`   Published: ${formatDate(result.pub_date)}`);
  return lines.join("\n");
};
var formatQuery = (eventIdx, query, idx) => {
  const header = `${eventIdx + 1}.${idx + 1} Search Query: ${query.query}
${query.results.length} results`;
  const results = query.results.map((result, resultIdx) => formatResult(result, resultIdx)).join("\n");
  return results ? `${header}
${results}` : header;
};
var formatEvent = (summaryEvent, idx) => {
  const header = `Search Event #${idx + 1}
${new Date(summaryEvent.timestamp).toLocaleString()}
${"=".repeat(80)}`;
  const queries = summaryEvent.queries.map((query, queryIdx) => formatQuery(idx, query, queryIdx)).join("\n");
  return `${header}
${queries}`;
};
var buildSummaryText = (events) => {
  const summaries = events.flatMap((event) => parseSummaryFromJson(event.rawResponse));
  return summaries.map((summary, idx) => formatEvent(summary, idx)).join(`

${"=".repeat(80)}

`);
};
var buildTocText = (events) => {
  const summaries = events.flatMap((event) => parseSummaryFromJson(event.rawResponse));
  const lines = summaries.map((summary, idx) => {
    const resultsCount = summary.queries.reduce((sum, q) => sum + q.results.length, 0);
    const header = `Event #${idx + 1} (${summary.queries.length} queries, ${resultsCount} results)`;
    const queries = summary.queries.map((query, qIdx) => `${idx + 1}.${qIdx + 1} ${query.query} (${query.results.length})`).join("\n");
    return `${header}
${queries}`;
  });
  return `Table of Contents
${lines.join("\n")}`;
};
var buildStatsText = (events) => {
  const stats = buildStats(events);
  const queries = stats.queries.join(", ") || "none";
  const domains = stats.domains.join(", ") || "none";
  const urls = stats.urls.join(", ") || "none";
  return [
    "Stats",
    `- Search events: ${stats.events}`,
    `- Unique queries: ${stats.queries.length} (${queries})`,
    `- Unique domains: ${stats.domains.length} (${domains})`,
    `- Unique URLs: ${stats.urls.length} (${urls})`
  ].join("\n");
};
var copyAllSummaries = async (events) => {
  const memo = "# This report was created by AI Search Inspector by Franz Enzenhofer - www.franzai.com - Specialist for SEO, GEO and AI SEO in Vienna, Austria";
  const text = [
    buildStatsText(events),
    buildTocText(events),
    buildSummaryText(events),
    memo
  ].join("\n\n");
  await navigator.clipboard.writeText(text);
};

// src/ui/rawView.ts
var rawContainer = byId("raw-container");
var renderRawItem = (event, idx) => {
  const json = event.rawResponse ?? "No response data";
  const formatted = formatJson(json);
  return [
    `<div class="raw-item">`,
    `<div class="raw-header">Response #${idx + 1} - ${escapeHtml(event.query)} (${json.length} bytes)<button class="copy-btn" data-copy-text="${escapeHtml(json)}">Copy JSON</button></div>`,
    `<div class="raw-response"><pre>${escapeHtml(formatted)}</pre></div>`,
    `</div>`
  ].join("");
};
var renderRawResponses = (events) => {
  if (!events.length) {
    setHtml(rawContainer, "");
    return;
  }
  const itemsHtml = events.map((event, idx) => renderRawItem(event, idx)).join("");
  setHtml(rawContainer, `<h2 id="full-json" class="section-title">Full JSON</h2>${itemsHtml}`);
};

// src/ui/statsView.ts
var statsContainer = byId("stats-container");
var formatStatsForCopy = (stats) => [
  `Search events: ${stats.events}`,
  `Unique queries: ${stats.queries.length}`,
  ...stats.queries.map((q) => `  - ${q}`),
  `Unique domains: ${stats.domains.length}`,
  ...stats.domains.map((d) => `  - ${d}`),
  `Unique URLs: ${stats.urls.length}`,
  ...stats.urls.map((u) => `  - ${u.url} (${u.count}x)`)
].join("\n");
var renderHeader = (copyPayload) => `<div class="stats-header"><span class="stats-title">Stats</span><button class="copy-btn" data-copy-text="${escapeHtml(copyPayload)}">Copy</button></div>`;
var statItemWithBadge = (label, count) => `<div class="stat-item"><span class="stat-label">${label} <span class="stat-count">${count}</span></span></div>`;
var renderQueries = (queries) => {
  if (!queries.length) return statItemWithBadge("Unique queries", 0);
  const list = queries.map((q) => `<span class="stat-query">${escapeHtml(q)}</span>`).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique queries <span class="stat-count">${queries.length}</span></span><div class="stat-queries">${list}</div></div>`;
};
var renderDomains = (domains) => {
  if (!domains.length) return statItemWithBadge("Unique domains", 0);
  const list = domains.map((d) => `<span class="stat-domain">${escapeHtml(d)}</span>`).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique domains <span class="stat-count">${domains.length}</span></span><div class="stat-domains">${list}</div></div>`;
};
var renderUrlItem = (u) => `<li class="stat-url-item"><a href="${escapeHtml(u.url)}" target="_blank" rel="noopener noreferrer" class="stat-url">${escapeHtml(u.url)}</a> <span class="stat-url-count">(${u.count}x)</span></li>`;
var renderUrls = (urls) => {
  if (!urls.length) return statItemWithBadge("Unique URLs", 0);
  const allUrls = urls.map((u) => u.url).join("\n");
  const list = urls.map(renderUrlItem).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique URLs <span class="stat-count">${urls.length}</span><button class="stat-toggle" data-toggle-target="urls-list">Hide</button><button class="stat-open-all" data-urls="${escapeHtml(allUrls)}">Open All</button></span><ul id="urls-list" class="stat-urls">${list}</ul></div>`;
};
var buildStatsHtml = (stats) => `${renderHeader(formatStatsForCopy(stats))}${statItemWithBadge("Search events", stats.events)}${renderQueries(stats.queries)}${renderDomains(stats.domains)}${renderUrls(stats.urls)}`;
var renderStats = (events) => {
  if (!events.length) {
    setHtml(statsContainer, "");
    statsContainer.classList.add("hidden");
    return;
  }
  statsContainer.classList.remove("hidden");
  setHtml(statsContainer, buildStatsHtml(buildStats(events)));
};

// src/ui/structuredView.ts
var structuredContainer = byId("structured-container");
var tocContainer = byId("toc-container");
var isNoQuery = (q) => q.toLowerCase().includes("no search query identified");
var countReal = (qs) => qs.filter((q) => !isNoQuery(q.query)).length;
var sumResults = (qs) => qs.reduce((s, q) => s + q.results.length, 0);
var renderResult = (r, ids) => {
  const copy = `${r.title}
${r.url}${r.snippet ? `
${r.snippet}` : ""}`, tid = `raw-${ids.e}-${ids.q}-${ids.r}`;
  const meta = [r.attribution ? `<span class="meta-item">Source: ${escapeHtml(r.attribution)}</span>` : "", r.pub_date ? `<span class="meta-item">Published: ${formatDate(r.pub_date)}</span>` : ""].join("");
  return `<div class="result-item"><div class="result-number">${ids.r + 1}</div><div class="result-content"><div class="result-title"><a href="${escapeHtml(r.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(r.title)}</a><button class="copy-btn-sm" data-copy-text="${escapeHtml(copy)}">Copy</button></div><div class="result-url url-copy" data-copy-text="${escapeHtml(r.url)}">${escapeHtml(r.url)}</div>${r.snippet ? `<div class="result-snippet">${escapeHtml(r.snippet)}</div>` : ""}<div class="result-metadata">${meta}</div><div class="result-actions"><button class="toggle-btn" data-toggle-id="${tid}">\u25B6 Show Raw JSON</button></div><div id="${tid}" class="result-raw-json hidden"><pre>${escapeHtml(r.rawJson)}</pre></div></div></div>`;
};
var searchLinks = (q) => isNoQuery(q) ? "" : `<a href="https://www.google.com/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener noreferrer" class="search-btn">Google</a><a href="https://www.bing.com/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener noreferrer" class="search-btn">Bing</a>`;
var renderQuery = (q, ei, qi) => {
  const results = q.results.map((r, ri) => renderResult(r, { e: ei, q: qi, r: ri })).join("");
  return `<div class="query-section" id="query-${ei}-${qi}"><div class="query-header"><strong>${ei + 1}.${qi + 1} Search Query:</strong> ${q.query}${searchLinks(q.query)}</div><div class="query-results">${results}</div></div>`;
};
var eventMeta = (real, total, ts) => real === 0 ? `${total} results \xB7 ${ts}` : `${real} ${real === 1 ? "query" : "queries"} \xB7 ${total} results \xB7 ${ts}`;
var renderEvent = (ev, idx) => {
  const total = sumResults(ev.queries), real = countReal(ev.queries), ts = new Date(ev.timestamp).toLocaleString();
  return `<div class="event-card" id="event-${idx}"><div class="event-header"><strong>Search Event #${idx + 1}</strong><span class="event-meta">${eventMeta(real, total, ts)}</span></div>${ev.queries.map((q, qi) => renderQuery(q, idx, qi)).join("")}</div>`;
};
var tocLink = (ei, real, total) => real === 0 ? `Event #${ei + 1} (${total} results)` : `Event #${ei + 1} (${real} ${real === 1 ? "query" : "queries"}, ${total} results)`;
var renderTocEvent = (ev, ei) => {
  const total = sumResults(ev.queries), real = countReal(ev.queries);
  const qs = ev.queries.map((q, qi) => `<a href="#query-${ei}-${qi}" class="toc-query-link">${ei + 1}.${qi + 1} ${q.query} (${q.results.length})</a>`).join("");
  return `<div class="toc-event"><a href="#event-${ei}" class="toc-event-link">${tocLink(ei, real, total)}</a><div class="toc-queries">${qs}</div></div>`;
};
var renderToc = (evs) => {
  if (!evs.length) {
    setHtml(tocContainer, "");
    return;
  }
  const totalQ = evs.reduce((s, e) => s + countReal(e.queries), 0), totalR = evs.reduce((s, e) => s + sumResults(e.queries), 0);
  const qPart = totalQ > 0 ? `${totalQ} ${totalQ === 1 ? "query" : "queries"}, ` : "";
  setHtml(tocContainer, `<div class="toc-title">Table of Contents (${qPart}${totalR} results)</div>${evs.map(renderTocEvent).join("")}<div class="toc-event"><a href="#full-json" class="toc-event-link">Full JSON</a></div>`);
};
var renderStructured = (events) => {
  if (!events.length) {
    setHtml(structuredContainer, "");
    setHtml(tocContainer, "");
    return;
  }
  const all = events.flatMap((e) => parseSummaryFromJson(e.rawResponse));
  if (!all.length) {
    setHtml(structuredContainer, `<div class="no-data">No search data found. Reload the ChatGPT tab to re-arm detection.</div>`);
    setHtml(tocContainer, "");
    return;
  }
  renderToc(all);
  setHtml(structuredContainer, all.map(renderEvent).join(""));
};

// src/ui/viewState.ts
var currentEvents = [];
var currentLogs = [];
var toggleTutorial = (hasEvents) => {
  const tutorial = document.getElementById("tutorial");
  if (tutorial) tutorial.classList.toggle("hidden", hasEvents);
};
var applyState = (events, logs) => {
  currentEvents = events;
  currentLogs = logs;
  renderStats(events);
  renderStructured(events);
  renderRawResponses(events);
  toggleTutorial(events.length > 0);
};
var getStateSnapshot = () => ({ events: currentEvents, logs: currentLogs });

// src/ui/controls.ts
var sendMessage = (type) => chrome.runtime.sendMessage({ type });
var handleClearData = () => {
  void sendMessage("clear-all-data").then(() => window.location.reload());
};
var handleHardReload = () => {
  void sendMessage("clear-all-data");
  void sendMessage("reload-detection");
  setTimeout(() => window.location.reload(), 100);
};
var handleCopyAll = () => {
  const { events } = getStateSnapshot();
  const button = document.getElementById("copy-all");
  const fallback = button?.textContent ?? "Copy all";
  void copyAllSummaries(events).then(() => flashText(button, "\u2713 Copied All", fallback));
};
var setupControls = () => {
  const on = (id, handler) => document.getElementById(id)?.addEventListener("click", handler);
  on("clear-data", handleClearData);
  on("hard-reload", handleHardReload);
  on("copy-all", handleCopyAll);
};

// src/ui/delegation.ts
var handleCopy = async (target) => {
  const copyText = target.getAttribute("data-copy-text");
  if (!copyText) return;
  const original = target.textContent ?? "Copy";
  try {
    await navigator.clipboard.writeText(copyText);
    flashText(target, "\u2713 Copied", original);
    showToast("Copied");
  } catch {
    flashText(target, "\u2717 Failed", original);
    showToast("Copy failed");
  }
};
var handleToggle = (target) => {
  const toggleId = target.getAttribute("data-toggle-id");
  if (!toggleId) return;
  const element = document.getElementById(toggleId);
  if (!element) return;
  const isHidden = element.classList.contains("hidden");
  element.classList.toggle("hidden");
  target.textContent = isHidden ? "\u25BC Hide Raw JSON" : "\u25B6 Show Raw JSON";
  const copyRow = element.querySelector(".raw-json-copy");
  if (copyRow) copyRow.classList.toggle("hidden", !isHidden);
};
var handleStatToggle = (target) => {
  const toggleTarget = target.getAttribute("data-toggle-target");
  if (!toggleTarget) return;
  const element = document.getElementById(toggleTarget);
  if (!element) return;
  const isHidden = element.classList.contains("hidden");
  element.classList.toggle("hidden");
  target.textContent = isHidden ? "Hide" : "Show";
  const openAllBtn = target.parentElement?.querySelector(".stat-open-all");
  if (openAllBtn) openAllBtn.classList.toggle("hidden", !isHidden);
};
var handleOpenAll = (target) => {
  const urlsData = target.getAttribute("data-urls");
  if (!urlsData) return;
  const urls = urlsData.split("\n").filter(Boolean);
  urls.forEach((url) => chrome.tabs.create({ url, active: false }));
  showToast(`Opening ${urls.length} URLs`);
};
var setupDelegation = () => {
  document.body.addEventListener("click", (event) => {
    const target = event.target;
    if (target.classList.contains("copy-btn-sm") || target.classList.contains("copy-btn")) void handleCopy(target);
    if (target.classList.contains("toggle-btn")) handleToggle(target);
    if (target.classList.contains("stat-toggle")) handleStatToggle(target);
    if (target.classList.contains("stat-open-all")) handleOpenAll(target);
    if (target.classList.contains("url-copy")) {
      const text = target.getAttribute("data-copy-text");
      if (text) navigator.clipboard.writeText(text).then(() => showToast("URL copied"));
    }
  });
};

// src/ui/panel.ts
var requestState = async () => {
  const response = await chrome.runtime.sendMessage({ type: "get-state" });
  applyState(response.events, response.logs);
};
var handleMessage = (message) => {
  const typed = message;
  if (typed.type === "state-updated" && typed.events && typed.logs) applyState(typed.events, typed.logs);
};
var notifyLifecycle = (type) => {
  void chrome.runtime.sendMessage({ type });
};
setupDelegation();
setupControls();
void requestState();
chrome.runtime.onMessage.addListener((message) => handleMessage(message));
notifyLifecycle("panel-opened");
window.addEventListener("beforeunload", () => notifyLifecycle("panel-closed"));
