// src/core/summaryResults.ts
var isSearchEntry = (entry) => Boolean(entry?.type === "search_result" && typeof entry.url === "string");
var pickAttribution = (group, entry) => {
  if (typeof group.domain === "string" && group.domain.length > 0) return group.domain;
  return typeof entry.attribution === "string" && entry.attribution.length > 0 ? entry.attribution : void 0;
};
var normalizeDate = (value) => {
  if (typeof value === "number") return value;
  return value === null ? null : void 0;
};
var buildResult = (entry, group) => ({
  title: typeof entry.title === "string" && entry.title.length ? entry.title : entry.url ?? "",
  url: entry.url ?? "",
  snippet: typeof entry.snippet === "string" ? entry.snippet : "",
  attribution: pickAttribution(group, entry),
  pub_date: normalizeDate(entry.pub_date),
  ref_id: typeof entry.ref_id === "object" && entry.ref_id ? entry.ref_id : void 0,
  type: "organic",
  rawJson: JSON.stringify(entry, null, 2)
});
var extractResults = (groups) => {
  if (!Array.isArray(groups)) return [];
  return groups.flatMap((group) => (group.entries ?? []).filter(isSearchEntry).map((entry) => buildResult(entry, group)));
};

// src/core/summaryQueries.ts
var readModelQueries = (metadata) => {
  const queries = metadata?.search_model_queries?.queries;
  return Array.isArray(queries) ? queries.filter((query) => typeof query === "string" && query.length > 0) : [];
};
var readSearchQueries = (metadata) => {
  const items = metadata?.search_queries;
  if (!Array.isArray(items)) return [];
  return items.filter((item) => item?.type === "search" && typeof item?.q === "string" && item.q.length > 0).map((item) => item.q);
};
var readQueries = (metadata) => {
  const model = readModelQueries(metadata);
  if (model.length) return model;
  return readSearchQueries(metadata);
};
var detectEventType = (node, mapping) => {
  const turnId = node.message?.metadata?.turn_exchange_id;
  if (!turnId) return "unknown";
  for (const n of Object.values(mapping)) {
    if (n.message?.metadata?.turn_exchange_id !== turnId) continue;
    if (n.message?.metadata?.search_display_string) return "search";
  }
  return "follow-up";
};
var findTurnQueries = (node, mapping) => {
  const turnId = node.message?.metadata?.turn_exchange_id;
  if (!turnId) return [];
  for (const n of Object.values(mapping)) {
    if (n.message?.metadata?.turn_exchange_id !== turnId) continue;
    const queries = readQueries(n.message?.metadata);
    if (queries.length) return queries;
  }
  return [];
};
var ancestorQueries = (node, mapping) => {
  let current = node.parent ? mapping[node.parent] : void 0;
  for (let depth = 0; depth < 3 && current; depth++) {
    const queries = readQueries(current.message?.metadata);
    if (queries.length) return queries;
    current = current.parent ? mapping[current.parent] : void 0;
  }
  return [];
};
var resolveQueries = (node, mapping) => {
  const fromNode = readQueries(node.message?.metadata);
  if (fromNode.length) return fromNode;
  const fromTurn = findTurnQueries(node, mapping);
  if (fromTurn.length) return fromTurn;
  const fromAncestors = ancestorQueries(node, mapping);
  return fromAncestors.length ? fromAncestors : ["no search query identified"];
};

// src/core/summaryEvents.ts
var getRefIndex = (result) => {
  const refId = result.ref_id;
  return typeof refId?.ref_index === "number" ? refId.ref_index : 999;
};
var findBoundaries = (indices, numQueries) => {
  if (numQueries <= 1 || indices.length === 0) return [];
  const sorted = [...indices].sort((a, b) => a - b);
  const gaps = [];
  for (let i = 1; i < sorted.length; i++) {
    gaps.push({ boundary: Math.floor((sorted[i - 1] + sorted[i]) / 2), gap: sorted[i] - sorted[i - 1] });
  }
  gaps.sort((a, b) => b.gap - a.gap);
  return gaps.slice(0, numQueries - 1).map((g) => g.boundary).sort((a, b) => a - b);
};
var distributeResults = (queries, results) => {
  if (queries.length <= 1) return [results];
  const indices = results.map(getRefIndex).filter((i) => i < 999);
  const boundaries = findBoundaries(indices, queries.length);
  const buckets = queries.map(() => []);
  results.forEach((r) => {
    const idx = getRefIndex(r);
    let bucket = 0;
    for (let i = 0; i < boundaries.length; i++) {
      if (idx > boundaries[i]) bucket = i + 1;
    }
    buckets[Math.min(bucket, queries.length - 1)].push(r);
  });
  return buckets;
};
var buildQueries = (node, mapping, results) => {
  const queries = resolveQueries(node, mapping);
  const distributed = distributeResults(queries, results);
  return queries.map((query, i) => ({ query, results: distributed[i] ?? [] }));
};
var toEvent = (node, mapping) => {
  const time = node.message?.create_time;
  const results = extractResults(node.message?.metadata?.search_result_groups);
  if (!results.length || typeof time !== "number") return void 0;
  const eventType = detectEventType(node, mapping);
  const turnId = node.message?.metadata?.turn_exchange_id;
  return { id: node.message?.id ?? `evt-${time}`, timestamp: time * 1e3, queries: buildQueries(node, mapping, results), eventType, turnId };
};
var mapToEvents = (nodes, mapping) => nodes.map((node) => toEvent(node, mapping)).filter((event) => Boolean(event));

// src/core/summaryMapping.ts
var parseJson = (raw) => {
  if (!raw) return void 0;
  try {
    return JSON.parse(raw);
  } catch {
    return void 0;
  }
};
var toMapping = (parsed) => {
  if (!parsed || typeof parsed !== "object") return {};
  const mapping = parsed.mapping;
  return mapping && typeof mapping === "object" ? mapping : {};
};
var isToolNode = (node) => node.message?.author?.role === "tool";
var sortNodes = (mapping) => Object.values(mapping).filter((node) => typeof node.message?.create_time === "number" && isToolNode(node)).sort((a, b) => (a.message?.create_time ?? 0) - (b.message?.create_time ?? 0));
var parseNodes = (rawJson) => {
  const mapping = toMapping(parseJson(rawJson));
  return { mapping, nodes: sortNodes(mapping) };
};

// src/core/parseSummary.ts
var parseSummaryFromJson = (rawJson) => {
  const { mapping, nodes } = parseNodes(rawJson);
  return mapToEvents(nodes, mapping);
};

// src/core/dedupeQueries.ts
var fingerprint = (results) => results.map((r) => r.url).sort().join("|");
var shouldKeep = (q, seen) => {
  const key = q.query.toLowerCase().trim(), fp = fingerprint(q.results), prev = seen.get(key);
  if (q.results.length === 0) return !seen.has(key);
  if (prev === void 0) {
    seen.set(key, fp);
    return true;
  }
  if (prev === fp) return false;
  seen.set(key, fp);
  return true;
};
var dedupeQueriesAcrossEvents = (events) => {
  const seen = /* @__PURE__ */ new Map();
  return events.map((e) => ({ ...e, queries: e.queries.filter((q) => shouldKeep(q, seen)) })).filter((e) => e.queries.length > 0);
};

// src/core/parseAndDedupe.ts
var parseAndDedupe = (events) => {
  const seen = /* @__PURE__ */ new Set();
  const parsed = events.flatMap((e) => parseSummaryFromJson(e.rawResponse)).filter((e) => {
    if (seen.has(e.id)) return false;
    seen.add(e.id);
    return true;
  });
  return dedupeQueriesAcrossEvents(parsed);
};

// src/core/stats.ts
var MULTI_PART_TLDS = /* @__PURE__ */ new Set(["co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "net.uk", "sch.uk", "com.au", "net.au", "org.au", "edu.au", "gov.au", "co.nz", "org.nz", "net.nz", "govt.nz", "ac.nz", "co.jp", "or.jp", "ne.jp", "ac.jp", "go.jp", "com.br", "org.br", "net.br", "gov.br", "edu.br", "co.in", "org.in", "net.in", "gov.in", "ac.in", "com.mx", "org.mx", "gob.mx", "edu.mx", "co.za", "org.za", "gov.za", "ac.za", "com.cn", "org.cn", "net.cn", "gov.cn", "edu.cn", "co.kr", "or.kr", "ne.kr", "go.kr", "ac.kr", "com.tw", "org.tw", "net.tw", "gov.tw", "edu.tw", "co.il", "org.il", "net.il", "gov.il", "ac.il", "com.sg", "org.sg", "net.sg", "gov.sg", "edu.sg", "com.hk", "org.hk", "net.hk", "gov.hk", "edu.hk", "co.id", "or.id", "go.id", "ac.id", "web.id", "com.gh", "org.gh", "gov.gh", "edu.gh", "com.ng", "org.ng", "gov.ng", "edu.ng", "co.ke", "or.ke", "go.ke", "ac.ke"]);
var rootDomain = (url) => {
  try {
    const host = new URL(url).hostname.toLowerCase(), parts = host.split(".").filter(Boolean);
    if (parts.length < 2) return host;
    const lastTwo = `${parts[parts.length - 2]}.${parts[parts.length - 1]}`;
    return MULTI_PART_TLDS.has(lastTwo) && parts.length >= 3 ? `${parts[parts.length - 3]}.${lastTwo}` : lastTwo;
  } catch {
    return void 0;
  }
};
var normalizeUrl = (url) => {
  try {
    const p = new URL(url);
    ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "ref", "trk"].forEach((k) => p.searchParams.delete(k));
    const q = p.searchParams.toString();
    return q ? `${p.origin}${p.pathname}?${q}` : `${p.origin}${p.pathname}`;
  } catch {
    return url;
  }
};
var isNoQuery = (q) => q.toLowerCase().includes("no search query identified");
var buildStats = (events) => {
  const all = parseAndDedupe(events);
  const queries = /* @__PURE__ */ new Set(), domains = /* @__PURE__ */ new Map(), urls = /* @__PURE__ */ new Map();
  all.forEach((ev) => ev.queries.forEach((q) => {
    if (!isNoQuery(q.query)) queries.add(q.query);
    q.results.forEach((r) => {
      if (!r.url) return;
      const norm = normalizeUrl(r.url);
      urls.set(norm, (urls.get(norm) ?? 0) + 1);
      const d = rootDomain(r.url);
      if (d) domains.set(d, (domains.get(d) ?? 0) + 1);
    });
  }));
  return {
    events: all.length,
    queries: Array.from(queries).sort(),
    domains: Array.from(domains.entries()).sort((a, b) => b[1] - a[1]).map(([d, c]) => `${d} (${c}x)`),
    urls: Array.from(urls.entries()).sort((a, b) => b[1] - a[1]).map(([u, c]) => ({ url: u, count: c }))
  };
};

// src/ui/dom.ts
var byId = (id) => document.getElementById(id);
var setHtml = (element, html) => {
  if (element) element.innerHTML = html;
};
var escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
var formatJson = (text) => {
  try {
    return JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    return text;
  }
};
var formatDate = (timestamp) => !timestamp ? "" : new Date(timestamp * 1e3).toLocaleDateString();
var flashText = (element, next, fallback) => {
  if (!element) return;
  element.textContent = next;
  setTimeout(() => {
    element.textContent = fallback;
  }, 1500);
};
var styleToast = (toast) => {
  Object.assign(toast.style, {
    position: "fixed",
    bottom: "12px",
    right: "12px",
    background: "#0b57d0",
    color: "#fff",
    padding: "6px 10px",
    borderRadius: "8px",
    fontSize: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.2)"
  });
};
var ensureToast = () => {
  const existing = document.getElementById("toast-banner");
  if (existing) return existing;
  const toast = document.createElement("div");
  toast.id = "toast-banner";
  styleToast(toast);
  document.body.appendChild(toast);
  return toast;
};
var showToast = (message) => {
  const toast = ensureToast();
  toast.textContent = message;
  toast.style.opacity = "1";
  setTimeout(() => {
    toast.style.opacity = "0";
  }, 1200);
};

// src/ui/copyAll.ts
var formatResult = (r, i) => {
  const lines = [`${i + 1}. ${r.title}`, `   URL: ${r.url}`];
  if (r.snippet) lines.push(`   Snippet: ${r.snippet}`);
  if (r.attribution) lines.push(`   Source: ${r.attribution}`);
  if (r.pub_date) lines.push(`   Published: ${formatDate(r.pub_date)}`);
  return lines.join("\n");
};
var formatQuery = (ei, q, qi) => {
  const h = `${ei + 1}.${qi + 1} Search Query: ${q.query}
${q.results.length} results`;
  const r = q.results.map((res, ri) => formatResult(res, ri)).join("\n");
  return r ? `${h}
${r}` : h;
};
var formatEvent = (ev, i) => {
  const h = `Search Event #${i + 1}
${new Date(ev.timestamp).toLocaleString()}
${"=".repeat(80)}`;
  return `${h}
${ev.queries.map((q, qi) => formatQuery(i, q, qi)).join("\n")}`;
};
var buildSummary = (events) => {
  const all = parseAndDedupe(events);
  return all.map((s, i) => formatEvent(s, i)).join(`

${"=".repeat(80)}

`);
};
var buildToc = (events) => {
  const all = parseAndDedupe(events);
  const totalQ = all.reduce((s, e) => s + e.queries.length, 0);
  const totalR = all.reduce((s, e) => s + e.queries.reduce((sum, q) => sum + q.results.length, 0), 0);
  const lines = all.map((s, i) => {
    const cnt = s.queries.reduce((sum, q) => sum + q.results.length, 0);
    const qs = s.queries.map((q, qi) => `${i + 1}.${qi + 1} ${q.query} (${q.results.length})`).join("\n");
    return `Event #${i + 1} (${s.queries.length} queries, ${cnt} results)
${qs}`;
  });
  return `TABLE OF CONTENTS (${totalQ} QUERIES, ${totalR} RESULTS)
${lines.join("\n")}`;
};
var buildStatsText = (events) => {
  const s = buildStats(events);
  const urls = s.urls.map((u) => `${u.url} (${u.count}x)`).join(", ") || "none";
  return `Stats
- Search events: ${s.events}
- Unique queries: ${s.queries.length} (${s.queries.join(", ") || "none"})
- Unique domains: ${s.domains.length} (${s.domains.join(", ") || "none"})
- Unique URLs: ${s.urls.length} (${urls})`;
};
var buildRawJson = (events) => {
  const jsons = events.map((e, i) => `=== RAW JSON Event #${i + 1} ===
${e.rawResponse ?? "No data"}`);
  return `FULL JSON DATA
${"=".repeat(80)}
${jsons.join("\n\n")}`;
};
var copyAllSummaries = async (events) => {
  const memo = "# This report was created by AI Search Inspector by Franz Enzenhofer - www.franzai.com - Specialist for SEO, GEO and AI SEO in Vienna, Austria";
  await navigator.clipboard.writeText([buildToc(events), buildStatsText(events), buildSummary(events), buildRawJson(events), memo].join("\n\n"));
};

// src/ui/rawView.ts
var rawContainer = byId("raw-container");
var renderRawItem = (event, idx) => {
  const json = event.rawResponse ?? "No response data";
  const formatted = formatJson(json);
  const desc = `Response #${idx + 1} - ${escapeHtml(event.query)} (${json.length} bytes)`;
  return `<div class="raw-item"><div class="raw-header">Full JSON</div><div class="raw-desc">${desc}</div><button class="copy-btn" data-copy-text="${escapeHtml(json)}">Copy JSON</button><div class="raw-response"><pre>${escapeHtml(formatted)}</pre></div></div>`;
};
var renderRawResponses = (events) => {
  if (!events.length) {
    setHtml(rawContainer, "");
    return;
  }
  const itemsHtml = events.map((event, idx) => renderRawItem(event, idx)).join("");
  setHtml(rawContainer, `<div id="full-json"></div>${itemsHtml}`);
};

// src/ui/statsView.ts
var statsContainer = byId("stats-container");
var currentUrls = [];
var getStatsUrls = () => currentUrls;
var formatStatsForCopy = (stats) => [
  `Search events: ${stats.events}`,
  `Unique queries: ${stats.queries.length}`,
  ...stats.queries.map((q) => `  - ${q}`),
  `Unique domains: ${stats.domains.length}`,
  ...stats.domains.map((d) => `  - ${d}`),
  `Unique URLs: ${stats.urls.length}`,
  ...stats.urls.map((u) => `  - ${u.url} (${u.count}x)`)
].join("\n");
var renderHeader = (copyPayload) => `<div class="stats-header"><span class="stats-title">Stats</span><button class="copy-btn" data-copy-text="${escapeHtml(copyPayload)}">Copy</button></div>`;
var statItemWithBadge = (label, count) => `<div class="stat-item"><span class="stat-label">${label} <span class="stat-count">${count}</span></span></div>`;
var renderQueries = (queries) => {
  if (!queries.length) return statItemWithBadge("Unique queries", 0);
  const list = queries.map((q) => `<span class="stat-query">${escapeHtml(q)}</span>`).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique queries <span class="stat-count">${queries.length}</span></span><div class="stat-queries">${list}</div></div>`;
};
var extractDomainName = (domainWithCount) => {
  const match = domainWithCount.match(/^(.+) \(\d+x\)$/);
  return match ? match[1] : domainWithCount;
};
var renderDomains = (domains) => {
  if (!domains.length) return statItemWithBadge("Unique domains", 0);
  const list = domains.map((d) => `<span class="stat-domain" data-domain="${escapeHtml(extractDomainName(d))}">${escapeHtml(d)}</span>`).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique domains <span class="stat-count">${domains.length}</span></span><div class="stat-domains">${list}</div></div>`;
};
var renderUrlItem = (u) => `<li class="stat-url-item"><a href="${escapeHtml(u.url)}" target="_blank" rel="noopener noreferrer" class="stat-url">${escapeHtml(u.url)}</a> <span class="stat-url-count">(${u.count}x)</span></li>`;
var renderUrls = (urls) => {
  if (!urls.length) return statItemWithBadge("Unique URLs", 0);
  const allUrls = urls.map((u) => u.url).join("\n");
  const list = urls.map(renderUrlItem).join("");
  return `<div class="stat-item stat-item-block"><span class="stat-label">Unique URLs <span class="stat-count">${urls.length}</span><button class="stat-toggle" data-toggle-target="urls-list">Hide</button><button class="stat-open-all" data-urls="${escapeHtml(allUrls)}">Open All</button></span><ul id="urls-list" class="stat-urls">${list}</ul></div>`;
};
var buildStatsHtml = (stats) => `${renderHeader(formatStatsForCopy(stats))}${statItemWithBadge("Search events", stats.events)}${renderQueries(stats.queries)}${renderDomains(stats.domains)}${renderUrls(stats.urls)}`;
var renderStats = (events) => {
  if (!events.length) {
    currentUrls = [];
    setHtml(statsContainer, "");
    statsContainer.classList.add("hidden");
    return;
  }
  statsContainer.classList.remove("hidden");
  const stats = buildStats(events);
  currentUrls = stats.urls;
  setHtml(statsContainer, buildStatsHtml(stats));
};

// src/ui/structuredView.ts
var structuredContainer = byId("structured-container");
var tocContainer = byId("toc-container");
var isNoQuery2 = (q) => q.toLowerCase().includes("no search query identified");
var countReal = (qs) => qs.filter((q) => !isNoQuery2(q.query)).length;
var sumResults = (qs) => qs.reduce((s, q) => s + q.results.length, 0);
var renderResult = (r, ids) => {
  const copy = `${r.title}
${r.url}${r.snippet ? `
${r.snippet}` : ""}`, tid = `raw-${ids.e}-${ids.q}-${ids.r}`;
  const meta = [r.attribution ? `<span class="meta-item">Source: ${escapeHtml(r.attribution)}</span>` : "", r.pub_date ? `<span class="meta-item">Published: ${formatDate(r.pub_date)}</span>` : ""].join("");
  return `<div class="result-item"><div class="result-number">${ids.r + 1}</div><div class="result-content"><div class="result-title"><a href="${escapeHtml(r.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(r.title)}</a><button class="copy-btn-sm" data-copy-text="${escapeHtml(copy)}">Copy</button></div><div class="result-url url-copy" data-copy-text="${escapeHtml(r.url)}">${escapeHtml(r.url)}</div>${r.snippet ? `<div class="result-snippet">${escapeHtml(r.snippet)}</div>` : ""}<div class="result-metadata">${meta}</div><div class="result-actions"><button class="toggle-btn" data-toggle-id="${tid}">\u25B6 Show Raw JSON</button></div><div id="${tid}" class="result-raw-json hidden"><pre>${escapeHtml(r.rawJson)}</pre></div></div></div>`;
};
var searchLinks = (q) => isNoQuery2(q) ? "" : `<a href="https://www.google.com/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener noreferrer" class="search-btn">Google</a><a href="https://www.bing.com/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener noreferrer" class="search-btn">Bing</a>`;
var renderQuery = (q, ei, qi) => {
  const results = q.results.map((r, ri) => renderResult(r, { e: ei, q: qi, r: ri })).join("");
  return `<div class="query-section" id="query-${ei}-${qi}"><div class="query-header"><strong>${ei + 1}.${qi + 1} Search Query:</strong> ${q.query}${searchLinks(q.query)}</div><div class="query-results">${results}</div></div>`;
};
var eventTypeLabel = (type) => {
  if (type === "follow-up") return `<span class="event-type event-type-followup" title="Follow-up or additional results">Follow-up</span>`;
  return "";
};
var eventMeta = (real, total, ts, type) => {
  const typeBadge = eventTypeLabel(type);
  const counts = real === 0 ? `${total} results` : `${real} ${real === 1 ? "query" : "queries"} \xB7 ${total} results`;
  return `${typeBadge} ${counts} \xB7 ${ts}`;
};
var renderEvent = (ev, idx) => {
  const total = sumResults(ev.queries), real = countReal(ev.queries), ts = new Date(ev.timestamp).toLocaleString();
  return `<div class="event-card" id="event-${idx}"><div class="event-header"><strong>Search Event #${idx + 1}</strong><span class="event-meta">${eventMeta(real, total, ts, ev.eventType)}</span></div>${ev.queries.map((q, qi) => renderQuery(q, idx, qi)).join("")}</div>`;
};
var tocLink = (ei, real, total) => real === 0 ? `Event #${ei + 1} (${total} results)` : `Event #${ei + 1} (${real} ${real === 1 ? "query" : "queries"}, ${total} results)`;
var renderTocEvent = (ev, ei) => {
  const total = sumResults(ev.queries), real = countReal(ev.queries);
  const qs = ev.queries.map((q, qi) => `<a href="#query-${ei}-${qi}" class="toc-query-link">${ei + 1}.${qi + 1} ${q.query} (${q.results.length})</a>`).join("");
  return `<div class="toc-event"><a href="#event-${ei}" class="toc-event-link">${tocLink(ei, real, total)}</a><div class="toc-queries">${qs}</div></div>`;
};
var renderToc = (evs) => {
  if (!evs.length) {
    setHtml(tocContainer, "");
    return;
  }
  const totalQ = evs.reduce((s, e) => s + countReal(e.queries), 0), totalR = evs.reduce((s, e) => s + sumResults(e.queries), 0);
  const qPart = totalQ > 0 ? `${totalQ} ${totalQ === 1 ? "query" : "queries"}, ` : "";
  setHtml(tocContainer, `<div class="toc-title">Table of Contents (${qPart}${totalR} results)</div>${evs.map(renderTocEvent).join("")}<div class="toc-event"><a href="#full-json" class="toc-event-link">Full JSON</a></div>`);
};
var renderStructured = (events) => {
  if (!events.length) {
    setHtml(structuredContainer, "");
    setHtml(tocContainer, "");
    return;
  }
  const all = parseAndDedupe(events);
  if (!all.length) {
    setHtml(structuredContainer, `<div class="no-data">No search data found. Reload the ChatGPT tab to re-arm detection.</div>`);
    setHtml(tocContainer, "");
    return;
  }
  renderToc(all);
  setHtml(structuredContainer, all.map(renderEvent).join(""));
};

// src/ui/viewState.ts
var currentEvents = [];
var currentLogs = [];
var toggleTutorial = (hasEvents) => {
  const tutorial = document.getElementById("tutorial");
  if (tutorial) tutorial.classList.toggle("hidden", hasEvents);
};
var applyState = (events, logs) => {
  currentEvents = events;
  currentLogs = logs;
  renderStats(events);
  renderStructured(events);
  renderRawResponses(events);
  toggleTutorial(events.length > 0);
};
var getStateSnapshot = () => ({ events: currentEvents, logs: currentLogs });

// src/ui/controls.ts
var sendMessage = (type) => chrome.runtime.sendMessage({ type });
var handleClearData = () => {
  void sendMessage("clear-all-data").then(() => window.location.reload());
};
var handleHardReload = () => {
  void sendMessage("clear-all-data");
  void sendMessage("reload-detection");
  setTimeout(() => window.location.reload(), 100);
};
var handleCopyAll = () => {
  const { events } = getStateSnapshot();
  const button = document.getElementById("copy-all");
  const fallback = button?.textContent ?? "Copy all";
  void copyAllSummaries(events).then(() => flashText(button, "\u2713 Copied All", fallback));
};
var setupControls = () => {
  const on = (id, handler) => document.getElementById(id)?.addEventListener("click", handler);
  on("clear-data", handleClearData);
  on("hard-reload", handleHardReload);
  on("copy-all", handleCopyAll);
};

// src/ui/domainOverlay.ts
var overlayElement = null;
var createOverlay = () => {
  const overlay = document.createElement("div");
  overlay.id = "domain-overlay";
  overlay.className = "domain-overlay";
  document.body.appendChild(overlay);
  return overlay;
};
var ensureOverlay = () => {
  if (!overlayElement) overlayElement = createOverlay();
  return overlayElement;
};
var renderUrlList = (urls) => urls.map((u) => `<li class="overlay-url-item"><a href="${escapeHtml(u.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(u.url)}</a> <span class="overlay-url-count">(${u.count}x)</span></li>`).join("");
var buildOverlayHtml = (domain, urls) => {
  const urlsText = urls.map((u) => u.url).join("\n");
  return `<div class="overlay-content"><div class="overlay-header"><span class="overlay-title">${escapeHtml(domain)}</span><button class="overlay-close">\u2715</button></div><ul class="overlay-urls">${renderUrlList(urls)}</ul><div class="overlay-footer"><button class="overlay-copy" data-copy-text="${escapeHtml(urlsText)}">Copy URLs</button></div></div>`;
};
var showDomainOverlay = (domain, allUrls) => {
  const filteredUrls = allUrls.filter((u) => rootDomain(u.url) === domain);
  if (!filteredUrls.length) return;
  const overlay = ensureOverlay();
  overlay.innerHTML = buildOverlayHtml(domain, filteredUrls);
  overlay.classList.add("visible");
};
var hideDomainOverlay = () => {
  if (overlayElement) overlayElement.classList.remove("visible");
};
var handleOverlayClick = async (target) => {
  if (target.classList.contains("overlay-close")) {
    hideDomainOverlay();
    return;
  }
  if (target.classList.contains("overlay-copy")) {
    const text = target.getAttribute("data-copy-text");
    if (text) {
      await navigator.clipboard.writeText(text);
      showToast("URLs copied");
    }
  }
};

// src/ui/delegation.ts
var handleCopy = async (target) => {
  const copyText = target.getAttribute("data-copy-text");
  if (!copyText) return;
  const original = target.textContent ?? "Copy";
  try {
    await navigator.clipboard.writeText(copyText);
    flashText(target, "\u2713 Copied", original);
    showToast("Copied");
  } catch {
    flashText(target, "\u2717 Failed", original);
    showToast("Copy failed");
  }
};
var handleToggle = (target) => {
  const toggleId = target.getAttribute("data-toggle-id");
  if (!toggleId) return;
  const element = document.getElementById(toggleId);
  if (!element) return;
  const isHidden = element.classList.contains("hidden");
  element.classList.toggle("hidden");
  target.textContent = isHidden ? "\u25BC Hide Raw JSON" : "\u25B6 Show Raw JSON";
  const copyRow = element.querySelector(".raw-json-copy");
  if (copyRow) copyRow.classList.toggle("hidden", !isHidden);
};
var handleStatToggle = (target) => {
  const toggleTarget = target.getAttribute("data-toggle-target");
  if (!toggleTarget) return;
  const element = document.getElementById(toggleTarget);
  if (!element) return;
  const isHidden = element.classList.contains("hidden");
  element.classList.toggle("hidden");
  target.textContent = isHidden ? "Hide" : "Show";
  const openAllBtn = target.parentElement?.querySelector(".stat-open-all");
  if (openAllBtn) openAllBtn.classList.toggle("hidden", !isHidden);
};
var handleOpenAll = (target) => {
  const urlsData = target.getAttribute("data-urls");
  if (!urlsData) return;
  const urls = urlsData.split("\n").filter(Boolean);
  urls.forEach((url) => chrome.tabs.create({ url, active: false }));
  showToast(`Opening ${urls.length} URLs`);
};
var handleDomainClick = (target) => {
  const domain = target.getAttribute("data-domain");
  if (domain) showDomainOverlay(domain, getStatsUrls());
};
var handleUrlCopy = (target) => {
  const text = target.getAttribute("data-copy-text");
  if (text) navigator.clipboard.writeText(text).then(() => showToast("URL copied"));
};
var handleClick = (target) => {
  if (target.classList.contains("copy-btn-sm") || target.classList.contains("copy-btn")) void handleCopy(target);
  if (target.classList.contains("toggle-btn")) handleToggle(target);
  if (target.classList.contains("stat-toggle")) handleStatToggle(target);
  if (target.classList.contains("stat-open-all")) handleOpenAll(target);
  if (target.classList.contains("stat-domain")) handleDomainClick(target);
  if (target.classList.contains("overlay-close") || target.classList.contains("overlay-copy")) void handleOverlayClick(target);
  if (target.classList.contains("domain-overlay")) hideDomainOverlay();
  if (target.classList.contains("url-copy")) handleUrlCopy(target);
};
var setupDelegation = () => {
  document.body.addEventListener("click", (event) => handleClick(event.target));
};

// src/ui/panel.ts
var requestState = async () => {
  const response = await chrome.runtime.sendMessage({ type: "get-state" });
  applyState(response.events, response.logs);
};
var handleMessage = (message) => {
  const typed = message;
  if (typed.type === "state-updated" && typed.events && typed.logs) applyState(typed.events, typed.logs);
};
var notifyLifecycle = (type) => {
  void chrome.runtime.sendMessage({ type });
};
setupDelegation();
setupControls();
void requestState();
chrome.runtime.onMessage.addListener((message) => handleMessage(message));
notifyLifecycle("panel-opened");
window.addEventListener("beforeunload", () => notifyLifecycle("panel-closed"));
