// src/core/parseSearchEvent.ts
var safeJson = (text) => {
  if (!text) return void 0;
  try {
    return JSON.parse(text);
  } catch {
    return void 0;
  }
};
var toMapping = (parsed) => {
  if (!parsed || typeof parsed !== "object") return {};
  const mapping = parsed.mapping;
  return mapping && typeof mapping === "object" ? mapping : {};
};
var sortNodes = (mapping) => Object.values(mapping).filter((node) => typeof node.message?.create_time === "number").sort((a, b) => (a.message?.create_time ?? 0) - (b.message?.create_time ?? 0));
var readQueries = (meta) => {
  const queries = meta?.search_model_queries?.queries;
  return Array.isArray(queries) ? queries.filter((q) => typeof q === "string" && q.length > 0) : [];
};
var resolveQuery = (node, mapping) => {
  const fromNode = readQueries(node.message?.metadata);
  if (fromNode.length) return fromNode.join(", ");
  const parentMeta = node.parent ? mapping[node.parent]?.message?.metadata : void 0;
  const fromParent = readQueries(parentMeta);
  return fromParent.length ? fromParent.join(", ") : "<unknown query>";
};
var toResults = (groups) => {
  if (!Array.isArray(groups)) return [];
  return groups.flatMap((groupRaw) => {
    const group = groupRaw;
    const entries2 = Array.isArray(group.entries) ? group.entries : [];
    return entries2.flatMap((entryRaw) => {
      const entry = entryRaw;
      if (entry.type !== "search_result" || typeof entry.url !== "string") return [];
      const title = typeof entry.title === "string" ? entry.title : entry.url;
      const attribution = typeof group.domain === "string" ? group.domain : typeof entry.attribution === "string" ? entry.attribution : void 0;
      return [{ title, url: entry.url, snippet: typeof entry.snippet === "string" ? entry.snippet : void 0, pub_date: typeof entry.pub_date === "number" ? entry.pub_date : entry.pub_date === null ? null : void 0, attribution, ref_id: typeof entry.ref_id === "object" && entry.ref_id ? entry.ref_id : void 0, type: "organic" }];
    });
  });
};
var toEvent = (node, capture, mapping) => {
  const metadata = node.message?.metadata;
  const results = toResults(metadata?.search_result_groups);
  const time = node.message?.create_time;
  if (!results.length || typeof time !== "number") return void 0;
  const ms = time * 1e3;
  const query = resolveQuery(node, mapping);
  return { id: node.message?.id ?? `evt-${time}`, query, url: capture.url, method: capture.method, status: capture.status, resultCount: results.length, results, rawResponse: capture.responseBody, startedAt: ms, completedAt: ms };
};
var parseSearchEvents = (capture) => {
  const mapping = toMapping(safeJson(capture.responseBody));
  return sortNodes(mapping).map((node) => toEvent(node, capture, mapping)).filter((event) => Boolean(event));
};
var parseSearchEvent = (capture) => parseSearchEvents(capture)[0];

// src/infra/effectWebRequestTap.ts
var toCapture = (details) => ({
  url: details.url,
  method: details.method,
  status: details.statusCode ?? 0,
  requestBody: void 0,
  responseBody: void 0,
  startedAt: Math.floor(details.timeStamp),
  completedAt: Math.floor(details.timeStamp)
});
var handleComplete = (details, onEvent) => {
  const event = parseSearchEvent(toCapture(details));
  if (event) onEvent(event);
};
var effectInitWebRequestTap = (onEvent) => {
  chrome.webRequest.onCompleted.addListener((details) => handleComplete(details, onEvent), { urls: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
};

// src/infra/effectSidePanel.ts
var isChatGpt = (url) => {
  if (!url) return false;
  return url.startsWith("https://chat.openai.com/") || url.startsWith("https://chatgpt.com/");
};
var enablePanel = (tabId, url) => {
  if (!isChatGpt(url)) return;
  void chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
  void chrome.sidePanel.open({ tabId });
};
var effectInitSidePanel = () => {
  chrome.action.onClicked.addListener((tab) => {
    if (!tab.id) return;
    enablePanel(tab.id, tab.url);
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") enablePanel(tabId, changeInfo.url ?? tab.url);
  });
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    enablePanel(activeInfo.tabId, tab.url);
  });
};

// src/logs/logStore.ts
var MAX_LOGS = 300;
var entries = [];
var createId = () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
var getLogs = () => entries;
var clearLogs = () => {
  entries = [];
};
var addLog = (level, tag, message, details) => {
  const log = { id: createId(), level, tag, message, details, timestamp: Date.now() };
  entries = [...entries.slice(-(MAX_LOGS - 1)), log];
  return log;
};
var hydrateLogs = (logs) => {
  entries = logs.slice(-MAX_LOGS);
};

// src/infra/effectDebuggerTap.ts
var targets = ["/backend-api/conversation", "process_upload_stream"];
var requests = /* @__PURE__ */ new Map();
var attachedTabId;
var listener;
var isTarget = (url) => Boolean(url && targets.some((needle) => url.includes(needle)));
var decodeBody = (result) => !result?.body ? void 0 : result.base64Encoded ? atob(result.body) : result.body;
var fetchBody = async (requestId) => !attachedTabId ? void 0 : decodeBody(await chrome.debugger.sendCommand({ tabId: attachedTabId }, "Network.getResponseBody", { requestId }));
var emitCapture = async (requestId, onEvent) => {
  const info = requests.get(requestId);
  if (!info) return;
  requests.delete(requestId);
  const capture = { url: info.url, method: info.method, requestBody: info.body, responseBody: await fetchBody(requestId), status: info.status ?? 0, startedAt: info.startedAt, completedAt: Date.now() };
  const event = parseSearchEvent(capture);
  if (event) onEvent(event);
};
var handleRequest = (params) => {
  const url = params.request?.url;
  const method = params.request?.method;
  if (!url || !isTarget(url) || !method) return;
  requests.set(params.requestId, { url, method, body: params.request?.postData, startedAt: Date.now() });
};
var handleResponse = (params) => {
  const info = requests.get(params.requestId);
  if (info) requests.set(params.requestId, { ...info, status: params.response?.status ?? info.status });
};
var handleFinished = (params, onEvent) => {
  void emitCapture(params.requestId, onEvent);
};
var onDebuggerEvent = (onEvent) => (source, method, params) => {
  if (source.tabId !== attachedTabId || !params) return;
  if (method === "Network.requestWillBeSent") handleRequest(params);
  if (method === "Network.responseReceived") handleResponse(params);
  if (method === "Network.loadingFinished") handleFinished(params, onEvent);
};
var enableDebugger = (tabId) => {
  chrome.debugger.attach({ tabId }, "1.3", () => {
    const err = chrome.runtime.lastError;
    if (err) {
      addLog("error", "capture", "debugger attach failed", { message: err.message });
      attachedTabId = void 0;
      return;
    }
    chrome.debugger.sendCommand({ tabId }, "Network.enable");
    addLog("info", "capture", "debugger attached", { tabId });
  });
};
var attachToTab = (tabId, onEvent) => {
  if (attachedTabId && attachedTabId !== tabId) chrome.debugger.detach({ tabId: attachedTabId });
  attachedTabId = tabId;
  if (!listener) listener = onDebuggerEvent(onEvent);
  chrome.debugger.onEvent.removeListener(listener);
  chrome.debugger.onEvent.addListener(listener);
  enableDebugger(tabId);
};
var findChatTab = async () => {
  const tabs = await chrome.tabs.query({ url: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
  const target = tabs.find((tab) => tab.active && tab.id) ?? tabs[0];
  return target?.id;
};
var maybeAttach = async (onEvent) => {
  const id = await findChatTab();
  if (id && id !== attachedTabId) attachToTab(id, onEvent);
};
var effectInitDebuggerTap = (onEvent) => {
  void maybeAttach(onEvent);
  chrome.tabs.onActivated.addListener(() => {
    void maybeAttach(onEvent);
  });
  chrome.tabs.onUpdated.addListener((_id, changeInfo, tab) => {
    if (changeInfo.status === "complete" && isTarget(tab.url)) void maybeAttach(onEvent);
  });
  chrome.debugger.onDetach.addListener(() => {
    attachedTabId = void 0;
    requests.clear();
  });
};

// src/infra/effectServiceWorker.ts
var EVENT_KEY = "search-events";
var LOG_KEY = "logs";
var loadState = async () => {
  const stored = await chrome.storage.session.get([EVENT_KEY, LOG_KEY]);
  const events = stored[EVENT_KEY] ?? [];
  hydrateLogs(stored[LOG_KEY] ?? []);
  return { events };
};
var persist = async (events) => chrome.storage.session.set({ [EVENT_KEY]: events, [LOG_KEY]: getLogs() });
var notifyPanels = (events) => {
  chrome.runtime.sendMessage({ type: "state-updated", events, logs: getLogs() }, () => {
    const err = chrome.runtime.lastError;
    if (err) addLog("warn", "ui", "notify panels failed", { message: err.message });
  });
};
var upsertEvent = async (event) => {
  const { events } = await loadState();
  const trimmed = [...events.filter((item) => item.id !== event.id).slice(-199), event];
  addLog("info", "capture", "search event captured", { query: event.query, url: event.url });
  await persist(trimmed);
  notifyPanels(trimmed);
};
var reloadChatTab = async () => {
  const tabs = await chrome.tabs.query({ url: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
  const target = tabs.find((tab) => tab.active) ?? tabs[0];
  if (!target?.id) {
    addLog("warn", "capture", "no ChatGPT tab found");
    await persist((await loadState()).events);
    return;
  }
  await chrome.tabs.reload(target.id);
  addLog("info", "capture", "reloaded ChatGPT tab");
  await persist((await loadState()).events);
};
var clearLogState = async () => {
  const { events } = await loadState();
  clearLogs();
  await persist(events);
  notifyPanels(events);
};
var clearAllData = async () => {
  clearLogs();
  await persist([]);
  notifyPanels([]);
  addLog("info", "capture", "all data cleared");
};
var handleSearchEvent = (event, sendResponse) => {
  if (!event) return false;
  void upsertEvent(event);
  sendResponse({ ok: true });
  return true;
};
var handleGetState = (sendResponse) => {
  void loadState().then((state) => sendResponse({ ...state, logs: getLogs() }));
  return true;
};
var handleReload = (sendResponse) => {
  void reloadChatTab().then(() => sendResponse({ ok: true }));
  return true;
};
var handleClearLogs = (sendResponse) => {
  void clearLogState().then(() => sendResponse({ ok: true }));
  return true;
};
var handleClearAllData = (sendResponse) => {
  void clearAllData().then(() => sendResponse({ ok: true }));
  return true;
};
var handleMessage = (message, sendResponse) => {
  const typed = message;
  if (typed.type === "search-event") return handleSearchEvent(typed.event, sendResponse);
  if (typed.type === "get-state") return handleGetState(sendResponse);
  if (typed.type === "reload-detection") return handleReload(sendResponse);
  if (typed.type === "clear-log") return handleClearLogs(sendResponse);
  if (typed.type === "clear-all-data") return handleClearAllData(sendResponse);
  return false;
};
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => handleMessage(message, sendResponse));
effectInitSidePanel();
effectInitDebuggerTap((event) => void upsertEvent(event));
effectInitWebRequestTap((event) => void upsertEvent(event));
