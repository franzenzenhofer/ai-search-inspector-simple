// src/logs/logStore.ts
var MAX_LOGS = 300;
var entries = [];
var createId = () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
var getLogs = () => entries;
var clearLogs = () => {
  entries = [];
};
var addLog = (level, tag, message, details) => {
  const log = { id: createId(), level, tag, message, details, timestamp: Date.now() };
  entries = [...entries.slice(-(MAX_LOGS - 1)), log];
  return log;
};
var hydrateLogs = (logs) => {
  entries = logs.slice(-MAX_LOGS);
};

// src/infra/eventStore.ts
var createState = () => ({ events: [], hydrated: false, queue: Promise.resolve() });
var ensureHydrated = async (state2, loadEvents2) => {
  if (state2.hydrated) return;
  state2.events = await loadEvents2();
  state2.hydrated = true;
};
var persistAndNotify = async (state2, persistEvents2, notify) => {
  await persistEvents2(state2.events);
  notify(state2.events);
};
var enqueue = (state2, task, logError) => {
  state2.queue = state2.queue.then(task).catch((error) => {
    logError(error);
    state2.queue = Promise.resolve();
  });
  return state2.queue;
};
var buildUpsert = (state2, loadEvents2, persistEvents2, notify, logError) => (event) => enqueue(state2, async () => {
  await ensureHydrated(state2, loadEvents2);
  state2.events = [...state2.events.filter((item) => item.id !== event.id).slice(-199), event];
  await persistAndNotify(state2, persistEvents2, notify);
}, logError);
var buildGet = (state2, loadEvents2) => async () => {
  await ensureHydrated(state2, loadEvents2);
  return state2.events;
};
var createEventStore = (loadEvents2, persistEvents2, notify, logError) => {
  const state2 = createState();
  const clear = async () => {
    await ensureHydrated(state2, loadEvents2);
    state2.events = [];
    await persistAndNotify(state2, persistEvents2, notify);
  };
  return { upsert: buildUpsert(state2, loadEvents2, persistEvents2, notify, logError), get: buildGet(state2, loadEvents2), clear };
};

// src/core/parseSearchEvent.ts
var safeJson = (text) => {
  if (!text) return void 0;
  try {
    return JSON.parse(text);
  } catch {
    return void 0;
  }
};
var toMapping = (parsed) => {
  if (!parsed || typeof parsed !== "object") return {};
  const mapping = parsed.mapping;
  return mapping && typeof mapping === "object" ? mapping : {};
};
var sortNodes = (mapping) => Object.values(mapping).filter((node) => typeof node.message?.create_time === "number").sort((a, b) => (a.message?.create_time ?? 0) - (b.message?.create_time ?? 0));
var readQueries = (meta) => {
  const queries = meta?.search_model_queries?.queries;
  return Array.isArray(queries) ? queries.filter((q) => typeof q === "string" && q.length > 0) : [];
};
var resolveQuery = (node, mapping) => {
  const fromNode = readQueries(node.message?.metadata);
  if (fromNode.length) return fromNode.join(", ");
  const parentMeta = node.parent ? mapping[node.parent]?.message?.metadata : void 0;
  const fromParent = readQueries(parentMeta);
  return fromParent.length ? fromParent.join(", ") : "<unknown query>";
};
var toResults = (groups) => {
  if (!Array.isArray(groups)) return [];
  return groups.flatMap((groupRaw) => {
    const group = groupRaw;
    const entries2 = Array.isArray(group.entries) ? group.entries : [];
    return entries2.flatMap((entryRaw) => {
      const entry = entryRaw;
      if (entry.type !== "search_result" || typeof entry.url !== "string") return [];
      const title = typeof entry.title === "string" ? entry.title : entry.url;
      const attribution = typeof group.domain === "string" ? group.domain : typeof entry.attribution === "string" ? entry.attribution : void 0;
      return [{ title, url: entry.url, snippet: typeof entry.snippet === "string" ? entry.snippet : void 0, pub_date: typeof entry.pub_date === "number" ? entry.pub_date : entry.pub_date === null ? null : void 0, attribution, ref_id: typeof entry.ref_id === "object" && entry.ref_id ? entry.ref_id : void 0, type: "organic" }];
    });
  });
};
var toEvent = (node, capture, mapping) => {
  const metadata = node.message?.metadata;
  const results = toResults(metadata?.search_result_groups);
  const time = node.message?.create_time;
  if (!results.length || typeof time !== "number") return void 0;
  const ms = time * 1e3;
  const query = resolveQuery(node, mapping);
  return { id: node.message?.id ?? `evt-${time}`, query, url: capture.url, method: capture.method, status: capture.status, resultCount: results.length, results, rawResponse: capture.responseBody, startedAt: ms, completedAt: ms };
};
var parseSearchEvents = (capture) => {
  const mapping = toMapping(safeJson(capture.responseBody));
  return sortNodes(mapping).map((node) => toEvent(node, capture, mapping)).filter((event) => Boolean(event));
};
var parseSearchEvent = (capture) => parseSearchEvents(capture)[0];

// src/infra/debuggerHandlers.ts
var isTarget = (targets, url) => Boolean(url && targets.some((needle) => url.includes(needle)));
var decodeBody = (result) => {
  if (!result?.body) return void 0;
  return result.base64Encoded ? atob(result.body) : result.body;
};
var fetchBody = async (state2, requestId) => {
  if (!state2.attachedTabId) return void 0;
  const response = await chrome.debugger.sendCommand({ tabId: state2.attachedTabId }, "Network.getResponseBody", { requestId });
  return decodeBody(response);
};
var buildCapture = async (state2, requestId) => {
  const info = state2.requests.get(requestId);
  if (!info) return void 0;
  state2.requests.delete(requestId);
  const capture = { url: info.url, method: info.method, requestBody: info.body, responseBody: await fetchBody(state2, requestId), status: info.status ?? 0, startedAt: info.startedAt, completedAt: Date.now() };
  return parseSearchEvent(capture);
};
var handleRequest = (state2, params) => {
  const url = params.request?.url;
  const method = params.request?.method;
  if (!url || !isTarget(state2.targets, url) || !method) return;
  const request = { url, method, body: params.request?.postData, startedAt: Date.now() };
  state2.requests.set(params.requestId, request);
};
var handleResponse = (state2, params) => {
  const info = state2.requests.get(params.requestId);
  if (info) state2.requests.set(params.requestId, { ...info, status: params.response?.status ?? info.status });
};
var handleFinished = async (state2, params) => {
  const event = await buildCapture(state2, params.requestId);
  if (event && state2.callback) state2.callback(event);
};
var buildDebuggerListener = (state2) => {
  return (source, method, params) => {
    if (source.tabId !== state2.attachedTabId || !params) return;
    if (method === "Network.requestWillBeSent") handleRequest(state2, params);
    if (method === "Network.responseReceived") handleResponse(state2, params);
    if (method === "Network.loadingFinished") void handleFinished(state2, params);
  };
};

// src/infra/debuggerState.ts
var createDebuggerState = () => ({
  targets: ["/backend-api/conversation", "process_upload_stream"],
  requests: /* @__PURE__ */ new Map()
});

// src/infra/effectDebuggerTap.ts
var state = createDebuggerState();
var enableDebugger = (tabId) => {
  chrome.debugger.attach({ tabId }, "1.3", () => {
    const err = chrome.runtime.lastError;
    if (err) {
      addLog("error", "capture", "debugger attach failed", { message: err.message });
      state.attachedTabId = void 0;
      return;
    }
    chrome.debugger.sendCommand({ tabId }, "Network.enable");
    addLog("info", "capture", "debugger attached", { tabId });
  });
};
var attachToTab = (tabId) => {
  if (state.attachedTabId && state.attachedTabId !== tabId) chrome.debugger.detach({ tabId: state.attachedTabId });
  state.attachedTabId = tabId;
  state.listener = state.listener ?? buildDebuggerListener(state);
  chrome.debugger.onEvent.removeListener(state.listener);
  chrome.debugger.onEvent.addListener(state.listener);
  enableDebugger(tabId);
};
var findChatTab = async () => {
  const tabs = await chrome.tabs.query({ url: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
  const target = tabs.find((tab) => tab.active && tab.id) ?? tabs[0];
  return target?.id;
};
var maybeAttach = async () => {
  const id = await findChatTab();
  if (id && id !== state.attachedTabId) attachToTab(id);
};
var attachDebugger = () => {
  if (!state.callback) {
    addLog("warn", "capture", "attachDebugger called but no callback stored");
    return;
  }
  void maybeAttach();
  addLog("info", "capture", "debugger attach requested (panel opened)");
};
var detachDebugger = () => {
  if (!state.attachedTabId) return;
  chrome.debugger.detach({ tabId: state.attachedTabId }, () => {
    const err = chrome.runtime.lastError;
    if (err) addLog("warn", "capture", "debugger detach failed", { message: err.message });
    else addLog("info", "capture", "debugger detached (panel closed)", { tabId: state.attachedTabId });
  });
  state.attachedTabId = void 0;
  state.requests.clear();
};
var effectInitDebuggerTap = (onEvent) => {
  state.callback = onEvent;
  state.listener = buildDebuggerListener(state);
  chrome.tabs.onActivated.addListener(() => {
    if (state.attachedTabId) void maybeAttach();
  });
  chrome.tabs.onUpdated.addListener((_id, changeInfo) => {
    if (state.attachedTabId && changeInfo.status === "complete") void maybeAttach();
  });
  chrome.debugger.onDetach.addListener(() => {
    state.attachedTabId = void 0;
    state.requests.clear();
    addLog("info", "capture", "debugger detached by external event");
  });
  chrome.debugger.onEvent.addListener(state.listener);
  addLog("info", "capture", "debugger tap initialized (not attached yet)");
};

// src/infra/effectSidePanel.ts
var hasSidePanel = () => Boolean(chrome.sidePanel?.setOptions);
var primePanel = async (tabId, url) => {
  if (!hasSidePanel()) {
    addLog("error", "ui", "side panel API unavailable");
    return;
  }
  await chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
  addLog("info", "ui", "side panel primed for tab", { tabId, url });
};
var openPanel = async (tabId, url) => {
  if (!hasSidePanel()) {
    addLog("error", "ui", "side panel API unavailable");
    return;
  }
  await chrome.sidePanel.open({ tabId });
  addLog("info", "ui", "side panel opened from action", { tabId, url });
};
var onActionClick = (tab) => {
  const id = tab.id;
  if (id === void 0) return;
  void primePanel(id, tab.url).then(() => openPanel(id, tab.url));
};
var setBehavior = () => {
  if (chrome.sidePanel?.setPanelBehavior) void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
};
var effectInitSidePanel = () => {
  setBehavior();
  chrome.action.onClicked.addListener(onActionClick);
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete") void primePanel(tabId, tab.url);
  });
  chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    void primePanel(activeInfo.tabId, tab.url);
  });
};

// src/infra/effectWebRequestTap.ts
var toCapture = (details) => ({
  url: details.url,
  method: details.method,
  status: details.statusCode ?? 0,
  requestBody: void 0,
  responseBody: void 0,
  startedAt: Math.floor(details.timeStamp),
  completedAt: Math.floor(details.timeStamp)
});
var handleComplete = (details, onEvent) => {
  const event = parseSearchEvent(toCapture(details));
  if (event) onEvent(event);
};
var effectInitWebRequestTap = (onEvent) => {
  chrome.webRequest.onCompleted.addListener((details) => handleComplete(details, onEvent), { urls: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
};

// src/infra/effectServiceWorker.ts
var EVENT_KEY = "search-events";
var LOG_KEY = "logs";
var loadEvents = async () => {
  const stored = await chrome.storage.session.get([EVENT_KEY, LOG_KEY]);
  hydrateLogs(stored[LOG_KEY] ?? []);
  return stored[EVENT_KEY] ?? [];
};
var persistEvents = async (events) => chrome.storage.session.set({ [EVENT_KEY]: events, [LOG_KEY]: getLogs() });
var notifyPanels = (events) => {
  chrome.runtime.sendMessage({ type: "state-updated", events, logs: getLogs() }, () => {
    const err = chrome.runtime.lastError;
    if (err) addLog("warn", "ui", "notify panels failed", { message: err.message });
  });
};
var store = createEventStore(
  loadEvents,
  persistEvents,
  notifyPanels,
  (error) => addLog("error", "storage", "event store failure", { message: `${error}` })
);
var reloadChatTab = async () => {
  const tabs = await chrome.tabs.query({ url: ["https://chat.openai.com/*", "https://chatgpt.com/*"] });
  const target = tabs.find((tab) => tab.active) ?? tabs[0];
  if (!target?.id) {
    addLog("warn", "capture", "no ChatGPT tab found");
    notifyPanels(await store.get());
    return;
  }
  await chrome.tabs.reload(target.id);
  addLog("info", "capture", "reloaded ChatGPT tab");
  notifyPanels(await store.get());
};
var clearLogState = async () => {
  const events = await store.get();
  clearLogs();
  await persistEvents(events);
  notifyPanels(events);
};
var clearAllData = async () => {
  clearLogs();
  await store.clear();
};
var handlers = {
  "search-event": (payload, sendResponse) => {
    if (!payload.event) return false;
    void store.upsert(payload.event);
    sendResponse({ ok: true });
    return true;
  },
  "get-state": (_payload, sendResponse) => {
    void store.get().then((events) => sendResponse({ events, logs: getLogs() }));
    return true;
  },
  "reload-detection": (_payload, sendResponse) => {
    void reloadChatTab().then(() => sendResponse({ ok: true }));
    return true;
  },
  "clear-log": (_payload, sendResponse) => {
    void clearLogState().then(() => sendResponse({ ok: true }));
    return true;
  },
  "clear-all-data": (_payload, sendResponse) => {
    void clearAllData().then(() => sendResponse({ ok: true }));
    return true;
  },
  "panel-opened": (_payload, sendResponse) => {
    addLog("info", "ui", "side panel opened, attaching debugger");
    attachDebugger();
    sendResponse({ ok: true });
    return true;
  },
  "panel-closed": (_payload, sendResponse) => {
    addLog("info", "ui", "side panel closed, detaching debugger");
    detachDebugger();
    sendResponse({ ok: true });
    return true;
  }
};
var handleMessage = (message, sendResponse) => {
  const typed = message;
  const handler = typed.type ? handlers[typed.type] : void 0;
  return handler ? handler(typed, sendResponse) : false;
};
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => handleMessage(message, sendResponse));
effectInitSidePanel();
effectInitDebuggerTap((event) => void store.upsert(event));
effectInitWebRequestTap((event) => void store.upsert(event));
